const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const session = require('express-session');

const app = express();
const port = 3000;

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Session middleware
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false,
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000
    },
    rolling: true
}));

// CORS middleware
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});

// Session check middleware - MOVE THIS HERE, BEFORE ROUTES
app.use((req, res, next) => {
    // Public paths that don't require authentication
    const publicPaths = [
        '/login.html',
        '/signup.html',
        '/api/login',
        '/api/signup',
        '/css/styles.css',
        '/js/auth.js',
        '/api/testimonials',
        '/fonts/fontawesome-webfont.woff2',
        '/fonts/fontawesome-webfont.woff',
        '/fonts/fontawesome-webfont.ttf'
    ];

    if (publicPaths.includes(req.path) || req.path.startsWith('/images/')) {
        return next();
    }

    if (!req.session || !req.session.userId) {
        if (req.path.startsWith('/api/')) {
            return res.status(401).json({ error: 'Please login first' });
        }
        return res.redirect('/login.html');
    }
    next();
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something broke!' });
});

// Update the logout endpoint
app.post('/api/logout', (req, res) => {
    console.log('Logout request received', req.session);
    
    if (!req.session) {
        console.log('No session found');
        return res.status(200).json({ message: 'Already logged out' });
    }

    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
            return res.status(500).json({ error: 'Error logging out' });
        }
        
        console.log('Session destroyed successfully');
        
        res.clearCookie('connect.sid', {
            path: '/',
            httpOnly: true,
            secure: false,
            sameSite: 'lax' // Changed from 'strict' to 'lax'
        });
        
        res.status(200).json({ message: 'Logged out successfully' });
    });
});

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'giftos_db'
});

// Handle database connection
db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        if (err.code === 'ER_BAD_DB_ERROR') {
            // Database doesn't exist, create it
            const tempDb = mysql.createConnection({
                host: 'localhost',
                user: 'root',
                password: 'root'
            });

            tempDb.connect((err) => {
                if (err) throw err;
                console.log('Creating database...');
                
                tempDb.query('CREATE DATABASE IF NOT EXISTS giftos_db', (err) => {
                    if (err) throw err;
                    console.log('Database created successfully');
                    
                    // Create users table
                    const createUsersTable = `
                        CREATE TABLE IF NOT EXISTS users (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            username VARCHAR(255) NOT NULL,
                            email VARCHAR(255) NOT NULL UNIQUE,
                            password VARCHAR(255) NOT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                        )
                    `;
                    
                    db.query(createUsersTable, (err) => {
                        if (err) {
                            console.error('Error creating users table:', err);
                        } else {
                            console.log('Users table ready');
                        }
                    });
                });
            });
        }
    } else {
        console.log('Connected to MySQL database');
    }
});

// Create testimonials table
const createTestimonialsTable = `
    CREATE TABLE IF NOT EXISTS testimonials (
        id INT AUTO_INCREMENT PRIMARY KEY,
        author VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        rating INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
`;

db.query(createTestimonialsTable, (err) => {
    if (err) {
        console.error('Error creating testimonials table:', err);
    } else {
        console.log('Testimonials table ready');
    }
});

// Add testimonial routes
app.post('/api/testimonials', async (req, res) => {
    console.log('Testimonial submission received:', req.body);
    const { author, content, rating } = req.body;

    // Validate input
    if (!author || !content || rating === undefined) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const [result] = await db.promise().query(
            'INSERT INTO testimonials (author, content, rating) VALUES (?, ?, ?)',
            [author, content, rating]
        );

        console.log('Testimonial saved:', result);
        res.json({ 
            message: 'Testimonial added successfully',
            testimonialId: result.insertId 
        });
    } catch (error) {
        console.error('Error saving testimonial:', error);
        res.status(500).json({ error: 'Error saving testimonial' });
    }
});

app.get('/api/testimonials', async (req, res) => {
    try {
        const [testimonials] = await db.promise().query(
            'SELECT * FROM testimonials ORDER BY created_at DESC'
        );
        
        console.log('Fetched testimonials:', testimonials.length);
        res.json(testimonials);
    } catch (error) {
        console.error('Error fetching testimonials:', error);
        res.status(500).json({ error: 'Error fetching testimonials' });
    }
});

// Update the signup endpoint with better error handling
app.post('/api/signup', async (req, res) => {
    console.log('Signup request received:', req.body);
    const { username, email, password } = req.body;

    // Validate input
    if (!username || !email || !password) {
        console.log('Missing required fields');
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        // Check if user already exists
        const [existingUsers] = await db.promise().query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );

        if (existingUsers.length > 0) {
            console.log('Email already registered');
            return res.status(400).json({ error: 'Email already registered' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert new user
        const [result] = await db.promise().query(
            'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
            [username, email, hashedPassword]
        );

        // Set session
        req.session.userId = result.insertId;
        req.session.username = username;

        console.log('User created successfully:', { id: result.insertId, username });
        res.status(200).json({
            message: 'User created successfully',
            user: { id: result.insertId, username, email }
        });

    } catch (error) {
        console.error('Signup error:', error);
        res.status(500).json({ error: 'Error during signup process' });
    }
});

// Login endpoint
app.post('/api/login', async (req, res) => {
    console.log('Login request received:', req.body);
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
        console.log('Missing email or password');
        return res.status(400).json({ error: 'Email and password are required' });
    }

    try {
        // Find user by email
        const [users] = await db.promise().query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );

        if (users.length === 0) {
            console.log('User not found');
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const user = users[0];

        // Compare password
        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
            console.log('Invalid password');
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Set session
        req.session.userId = user.id;
        req.session.username = user.username;

        console.log('Login successful:', { id: user.id, username: user.username });
        res.json({ 
            message: 'Login successful',
            user: { 
                id: user.id, 
                username: user.username, 
                email: user.email 
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Error during login process' });
    }
});

// Add this route for session check
app.get('/api/check-session', (req, res) => {
    if (req.session && req.session.userId) {
        res.json({ 
            authenticated: true, 
            userId: req.session.userId,
            username: req.session.username 
        });
    } else {
        res.json({ authenticated: false });
    }
});

// Your other routes go here...

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/code.html`);
}); 