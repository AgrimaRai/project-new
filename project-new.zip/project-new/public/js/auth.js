// Logout functionality
function setupLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            console.log('Logout clicked');
            
            try {
                const response = await fetch('/api/logout', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    credentials: 'same-origin'
                });
                
                console.log('Logout response:', response);
                
                // Redirect to login page regardless of response
                window.location.href = '/login.html';
            } catch (error) {
                console.error('Error during logout:', error);
                // Redirect to login page even if there's an error
                window.location.href = '/login.html';
            }
        });
    } else {
        console.warn('Logout button not found');
    }
}

// Call setup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('Setting up logout handler');
    setupLogout();
}); 